package com.example.ss_companionapp

import android.app.Application

class Globals: Application() {
    var user_id : Int = 0
}