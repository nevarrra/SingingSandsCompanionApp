package com.example.ss_companionapp

import android.app.Activity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity

public class RuneSeekBar: AppCompatActivity() {

    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}
