package com.example.ss_companionapp

import java.util.*

class History (val user1: String, val user2: String, val battleOutcome: String, val battleDate: Date) {

}